import React from 'react'
import MapImage from './images/MapImage.jpg'
function Content() {
    return (
        <>
            <section id="section1">
                <span class="fs-1 fw-bolder">Contact Us</span>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit,
                    <br />Lorem ipsum dolor sit amet consectetur adipisicing elit.
                </p>
                <ul class='p-0'>
                    <li>Home</li>
                    <li><i class="fa-solid fa-angles-right"></i></li>
                    <li>Contact Us</li>
                </ul>
            </section>
            <section class='d-flex align-items-center justify-content-evenly'>
                <div id="contact_info">
                    <span class='fs-2 fw-bolder'>Let's Start <br />Something Great!</span>
                    <p class="paratext">Proactively customize cross-media schemas rather than high-payoff the customer
                        service. uniquely enable extensible niche.</p>
                    <div class="d-flex align-items-center">
                        <span class="contact_icon"><i class="fa-solid fa-location-dot"></i></span>
                        <p class="contact_text"><br />Akshya Nagar 1<sup>st</sup> Block 1<sup>st</sup> Cross,<br /> Rammurthy
                            Nagar,<br /> Bangalore-560016</p>
                    </div>
                    <div class="d-flex align-items-center mb-4">
                        <span class="contact_icon"><i class="fa-solid fa-mobile-screen"></i></span>
                        <span class="contact_text">+911234567890</span>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="contact_icon"><i class="fa-regular fa-envelope"></i></span>
                        <span class="contact_text">info@company.com</span>
                    </div>
                </div>
                <div class="card" id="inquiry_form">
                    <span class='fs-4 fw-bolder'>Need Help?</span>
                    <p class="paratext">Proactively fasion world-class leadership vis-a-vis enterprise e-services. Great
                        strong leadership.
                    </p>
                    <form>
                        <div>
                            <i class="fa-regular fa-user"></i>
                            <input type="text" placeholder="Name" />
                        </div>
                        <div>
                            <i class="fa-regular fa-envelope"></i>
                            <input type="text" placeholder="Email" />
                        </div>
                        <div>
                            <i class="fa-solid fa-tag"></i>
                            <input type="text" placeholder="Subject" />
                        </div>
                        <div>
                            <i class="fa-regular fa-pen-to-square"></i>
                            <textarea cols="30" rows="10" placeholder="Your message" />
                        </div>
                        <button>SEND INQUIRY</button>
                    </form>
                </div>
            </section>
            <img src={MapImage} alt='location' id='location' />
        </>
    )
}
export default Content