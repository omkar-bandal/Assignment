import './App.css';
import Navigationbar from './Navigationbar';
import Content from './Content';
import Footer from './Footer';
function App() {
  return (
    <>
      <header>
        <Navigationbar />
      </header>
      <main>
        <Content />
      </main>
      <footer>
        <Footer />
      </footer>
    </>
  );
}

export default App;
