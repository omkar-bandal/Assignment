import React from 'react'

function Footer() {
    return (
        <>
            <div class="footer1">
                <div class="follow_us">
                    <span class="fs-6 fw-bolder">FOLLOW US <span class='corner'>◣</span></span>
                    <div class="d-flex align-items-center my-3">
                        <i class="fa-brands fa-linkedin"></i>
                        <i class="fa-brands fa-telegram"></i>
                        <i class="fa-brands fa-square-twitter"></i>
                    </div>
                    <div class="d-flex align-items-center">
                        <i class="fa-solid fa-globe"></i>
                        <span class="paratext">https://company.com</span>
                    </div>
                </div>
                <div class="our_services d-flex flex-column">
                    <span class="fs-6 fw-bolder">OUT SERVICES <span class='corner'>◣</span></span>
                    <div class='d-flex justify-content-between mt-3'>
                        <ul class="p-0">
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                        </ul>
                        <ul class="p-0">
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                            <li><i class="fa-solid fa-angles-right"></i>Lorem ipsum dolor</li>
                        </ul>
                    </div>
                </div>
                <div class="get_in_touch d-flex flex-column">
                    <span class="fs-6 fw-bolder">GET IN TOUCH <span class='corner'>◣</span></span>
                    <div class='mt-3 border-bottom border-light'>
                        <span><i class="fa-solid fa-location-dot"></i></span>
                        <p>Akshya Nagar 1<sup>st</sup> Block 1<sup>st</sup> Cross,<br /> Rammurthy Nagar,<br /> Bangalore-560016
                        </p>
                    </div>
                    <div class='my-2'>
                        <span><i class="fa-solid fa-mobile-screen"></i></span>
                        <span>Phone : +911234567890</span>
                    </div>
                    <div>
                        <span><i class="fa-regular fa-envelope"></i></span>
                        <span>Email : info@company.com</span>
                    </div>
                </div>
            </div>
            <div class="footer2">
                <span>Copyright © 2023, iAssureIT All Right Reserved</span>
                <span>Designed & Developed By <strong>iAssure International Technologies Pvt. Ltd.</strong></span>
            </div>
        </>
    )
}
export default Footer