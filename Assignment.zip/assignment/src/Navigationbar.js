import React from 'react'

function Navigationbar() {
    return (
        <>
            <div class="header1 d-flex align-items-center justify-content-end">
                <div>
                    <i class="fa-solid fa-mobile-screen"></i>
                    <span>+911234567890</span>
                </div>
                <div>
                    <i class="fa-regular fa-envelope"></i>
                    <span>info@company.com</span>
                </div>
            </div>
            <div class="header2 d-flex align-items-center justify-content-between">
                <h2 id='logo'>LOGO</h2>
                <nav class='pt-2'>
                    <ul class="d-flex align-items-center list-unstyled">
                        <li><a class="navbar_option" href='/'>HOME</a></li>
                        <li><a class="navbar_option" href='/'>ABOUT US</a></li>
                        <li><a class="navbar_option" href='/'>SERVICES</a></li>
                        <li><a class="navbar_option" href='/'>TESTIMONIALS</a></li>
                        <li><a class="navbar_option" href='/'>BLOGS</a></li>
                        <li><a class="navbar_option activepage" href='/'>CONTACT</a></li>
                    </ul>
                </nav>
            </div>
        </>
    )
}
export default Navigationbar